import {Injectable} from "@angular/core";

@Injectable()
export abstract class LoggingService {

  log(message: string): void { };
}
