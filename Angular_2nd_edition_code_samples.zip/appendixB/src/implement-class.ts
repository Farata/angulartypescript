class ProductService {
    saveProduct(productID:number): void{
      // TODO: implement here
    }
}

class MockProductService implements ProductService{
    saveProduct(productId: number):void{
        
    }
}
