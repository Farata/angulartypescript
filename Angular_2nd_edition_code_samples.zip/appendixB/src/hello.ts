let myName:string;

myName="Mary";

console.log(`Hello ${myName}`);