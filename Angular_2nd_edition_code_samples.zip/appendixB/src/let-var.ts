(function (){

        if (true) {
         let customer = "Mary";
         console.log("The name of the customer inside the block is "  + customer);
        }

         //console.log("The name of the customer outside the block is "  + customer);

    })();