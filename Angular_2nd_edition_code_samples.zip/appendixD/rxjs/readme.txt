After running npm install, you can any of these RxJS code samples from the command line using Node.js, for example: node flatmap.js.
