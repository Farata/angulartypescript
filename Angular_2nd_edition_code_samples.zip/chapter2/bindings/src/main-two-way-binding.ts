import './polyfills.ts';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/two-way/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
