This folder contains code samples from the book "Angular Development with TypeScript", Second Edition. It's work in progress and Manning is about to start the MEAP program of this book so you can get the new chapters as we complete them. As of October 2, 2017 about half of the book is ready. Currently all examples use the latest release of Angular 4, and we'll upgrade all the code samples as soon as Angular 5 is released.  

We used Angular CLI 1.4 for projects generation. You may need to install it globally to run these samples.
