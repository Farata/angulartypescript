import './polyfills.ts';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/basic/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
