import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `    
    <product1></product1>
    <p>
    <product2></product2>
  `
})
export class AppComponent {}
