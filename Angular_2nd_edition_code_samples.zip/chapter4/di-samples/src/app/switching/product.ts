export class Product {
  constructor( public title: string) {
  }
}
