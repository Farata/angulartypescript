import './polyfills.ts';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/master-detail/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
