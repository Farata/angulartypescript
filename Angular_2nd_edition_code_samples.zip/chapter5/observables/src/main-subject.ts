import './polyfills.ts';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/subject/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
