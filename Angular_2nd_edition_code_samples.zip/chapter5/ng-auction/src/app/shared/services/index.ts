import { ProductService, Product } from './product.service';

export { ProductService, Product} from './product.service';

